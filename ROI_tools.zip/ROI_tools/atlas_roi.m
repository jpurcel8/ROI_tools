function [ nifti_out] = atlas_roi
% Edits a standard MRI structural atlas. The input atlas must have regions
% numbered as whole numbers. Examples include the Harvard-Oxford or AAL3
% atlases, but any atlas formated as such will work. 
%
% Input atlas_roi in the command window to run. This allows you to obtain 
% regions of interest anatomical brain atlas. You must know the number of 
% the regions you wish to remove from or include in a new brain file or set 
% of brain files.  To obtain these region numbers for the AAL3 and the Harvard 
% Oxford atlas see the Atlas_Regions.xls spreadsheet within the Research_Atlases 
% folder.
% �ex� : Allows you to exclude a set of numbered region from a standard brain 
% atlas. Saves output as one nifti file.

% �inc-all� :  Allows you to include a set of numbered regions from a standard 
% brain atlas. Saves output as one nifti file.

% �inc� :  Allows you to include a set of numbered regions from a standard 
% brain atlas. Saves output as multiple nifti files. 

% NOTE: to edit the default parameters search for the line %% edit default parameters %%, 
% and edit appropriate default parameters. 

% NOTE: the left/right notation is based on the Harvard-Oxford and AAL3
% atlas formats. This may not work with every atlas, so check the output
% and switch left/right appropriately if the output has left/right swapped!!

% Tested in Matlab Version 2019a 

%% Code is for research purposes only. Clinical use has not been tested.
%% Copyright 2020, Jeremy Joseph Purcell, All rights reserved.

%% edit default parameters %%
% edit to change the default parameters that are displayed in the gui
% exclude regions 'ex' (default), include all regions 'inc-all', or include seperate regions 'inc'
% bilateral images (default)
% regions 1,3, and 8 are the bilateral white matter, csf, and brain stem of
% the combined Harvard Oxford cortical and subcortical atlas
def={'ex';'default';'1 3 8'}; %Set run names here!!! Can change the default if using for different experiment
%% identify folders with data
data_input=uipickfiles('FilterSpec', '*.ni*', 'Prompt', 'Select a single nifti format standard atlas');
[pa na ex]=fileparts(data_input{:});

if ~contains(na,'.nii')==0
    na(strfind(na,'.nii'):strfind(na,'.nii')+3)=[];
end
if ~contains(na,'.gz')==0
    na(strfind(na,'.gz'):strfind(na,'.gz')+2)=[];
end

%% set input parameters
clear prompt input_name
prompt= {'ex = exclude; inc-all = combined area; inc = seperate areas';'default(leave blank), left, or right';'area # eg.[1 3 8 12 14]'};
num_lines = 1;
dlg_title = 'Edit Atlas Parameters';
input_param=inputdlg(prompt,dlg_title,num_lines,def);
input_nums=input_param{3};
input_nums(isspace(input_param{3}))='_';

%% input data
nifti_input=niftiread(data_input{:});
nii_info_group_output=niftiinfo(data_input{:});
nii_info_group_output.Datatype='single';
%% exclude regions
if strncmp(input_param{1},'ex',5)
    nifti_input_out=nifti_input;
    for i=str2num(input_param{3})
        nifti_input_out(nifti_input_out==i)=0;
    end
    output_path=fullfile(pa, sprintf('%s_ex_regions%s',na,input_nums));
    
    sizni=size(nifti_input_out);
    if strncmp(input_param{2},'right',5)
        nifti_input_out(round(sizni(1)/2)+1:end,:,:)=0;
        output_path=fullfile(pa, sprintf('%s_ex_right_regions%s',na,input_nums));
    elseif strncmp(input_param{2},'left',5)
        nifti_input_out(1:round(sizni(1)/2),:,:)=0;
        output_path=fullfile(pa, sprintf('%s_ex_left_regions%s',na,input_nums));
    end
    
    niftiwrite(single(nifti_input_out),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
end

%% include all regions
if strncmp(input_param{1},'inc-all',5)
    nifti_input_out=zeros(size(nifti_input));
    for i=str2num(input_param{3})
        nifti_input_out(nifti_input==i)=1;
    end
    
    output_path=fullfile(pa, sprintf('%s_inc-all_regions%s',na,input_nums));
    
    sizni=size(nifti_input_out);
    if strncmp(input_param{2},'right',5)
        nifti_input_out(round(sizni(1)/2)+1:end,:,:)=0;
        output_path=fullfile(pa, sprintf('%s_ex_right_inc-all_regions%s',na,input_nums));
    elseif strncmp(input_param{2},'left',5)
        nifti_input_out(1:round(sizni(1)/2),:,:)=0;
        output_path=fullfile(pa, sprintf('%s_ex_left_inc-all_regions%s',na,input_nums));
    end
    
    niftiwrite(single(nifti_input_out),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
end

%% include seperate regions
if strncmp(input_param{1},'inc',5)
    regions=str2num(input_param{3});
    for i=regions
        nifti_input_out=zeros(size(nifti_input));
        nifti_input_out(nifti_input==i)=1;
        output_path=fullfile(pa, sprintf('%s_inc_region%d',na,i));
        
        sizni=size(nifti_input_out);
        if strncmp(input_param{2},'right',5)
            nifti_input_out(round(sizni(1)/2)+1:end,:,:)=0;
            output_path=fullfile(pa, sprintf('%s_ex_right_inc_region%s',na,input_nums));
        elseif strncmp(input_param{2},'left',5)
            nifti_input_out(1:round(sizni(1)/2),:,:)=0;
            output_path=fullfile(pa, sprintf('%s_ex_left_inc_region%s',na,input_nums));
        end
        
        niftiwrite(single(nifti_input_out),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
    end
end

