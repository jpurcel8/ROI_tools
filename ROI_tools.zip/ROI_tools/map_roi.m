function map_roi
% Obtain regions of interest from a 3d nifti format map
% You can use either statistical maps or binary maps
% Input can be multiple files.

% Input map_roi in the command window to run. This allows you to obtain 
% regions of interest from a statistical map. You must know the voxel level 
% threshold, cluster size threshold (in voxels), and connectivity that you 
% wish to use to define the clusters in your ROI.

%Options:
% �cluster-index� : outputs a single file (2 files if you indicate both 
% positive and negative clusters) with a rank order number assigned to each 
% cluster from largest to smallest. E.g. the largest cluster will have a number 
% of 1 assigned to each voxel in the cluster. The output file name will have 
% the voxel threshold, cluster threshold. and whether it is a positive (pos) 
% or negative (neg).

% �clusters�: outputs a single file for each cluster with a rank order number 
% assigned to each cluster from largest to smallest. E.g. the largest cluster 
% will have a number of 1 assigned to each voxel in the cluster.  The output 
% file name will have the voxel threshold, cluster threshold. the rank order 
% cluster #, size of the cluster in voxels, whether it is positive (pos) or 
% negative (neg), and the center of mass voxel. 

% NOTE: to edit the default parameters search for the line %% edit default parameters %%, 
% and edit appropriate default parameters.

% Tested in Matlab Version 2019a

%% Code is for research purposes only. Clinical use has not been tested.
%% Copyright 2020, Jeremy Joseph Purcell, All rights reserved.

%% edit default parameters %%
% edit to change the default parameters that are displayed in the gui
% 'cluster-index' (default); 'clusters'
% voxel threshold default = 2.3
% positive (default), negative or both positive and negative clusters
% include face/edge/corner (default) in cluster definition
% default cluster size threfhold = 200 voxels
def={'cluster-index';'2.3';'positive'; 'fec';'200'};
%% identify folders with data
data_input=uipickfiles('FilterSpec', '*.ni*', 'Prompt', 'Select a signle or multiple nifti maps (i.e. it will loop through each file you select)');

for n=1:size(data_input,2)
    [pa na ex]=fileparts(data_input{n});
    
    if ~contains(na,'.nii')==0
        na(strfind(na,'.nii'):strfind(na,'.nii')+3)=[];
    end
    if ~contains(na,'.gz')==0
        na(strfind(na,'.gz'):strfind(na,'.gz')+2)=[];
    end
    %% set input parameters
    clear prompt input_name
    prompt= {'cluster-index = clusters numbered in 1 file; clusters = 1 file per region';'voxel threshold value (use absolute value; set to 1 if binary file)';...
        'map values: positive, negative, or both';'connectivty: fec = face/edge/corner, fe = face/edge, f = face'; ...
        'cluster size threshold (based on voxel count input file)'};
    num_lines = 1;
        dlg_title = 'Edit a statistical map file';
    input_param=inputdlg(prompt,dlg_title,num_lines,def);
    
    %% input data
    nifti_input=niftiread(data_input{n});
    nii_info_group_output=niftiinfo(data_input{n});
    nii_info_group_output.Datatype='single';
    conn_txt=input_param{4};
    
    if strncmp(conn_txt,'fec',3)
        conn=26; %default
    elseif strncmp(conn_txt,'fe',3)
        conn=18;
    else
        conn=6;
    end
    
    threshval=abs(str2num(input_param{2}));
    clust_thresh=abs(str2num(input_param{5}));
    
    threshval_out=num2str(threshval);
    threshval_out(threshval_out=='.')='-';
    %% index a map with different rois
    if strncmp(input_param{1},'cluster-index',10)
        nifti_input_out=nifti_input;
        
        if strncmp(input_param{3},'positive',5)||strncmp(input_param{3},'both',5)
            nifti_input_out(nifti_input<threshval)=0;
            
            found_clusters=bwlabeln(nifti_input_out,conn);
            cluster_tally=unique(found_clusters);
            cluster_tally(1)=[];
            for j=1:size(cluster_tally,1)
                size_tally(j,1)=size(find(found_clusters==cluster_tally(j,1)),1);
                if size_tally(j,1)<clust_thresh
                    found_clusters(found_clusters==j)=0;
                end
            end
            found_clusters_out=bwlabeln(found_clusters,conn);
            if size(find(found_clusters_out),1)==0
                disp('Warning, no positive clusters found at this threshold');
            else
                cluster_track=unique(found_clusters_out);
                num_clusters=size(cluster_track,1)-1;
                fprintf('%d positive clusters\n',num_clusters);
                found_clusters_out_resort=found_clusters_out;
                t=0;
                for jj=2:size(cluster_track,1)
                    t=t+1;
                    clusters_size(t,1)=size(find(found_clusters_out==cluster_track(jj)),1);
                    clusters_size(t,2)=t;
                end
                
                clusters_size_resort=sortrows(clusters_size,1,'descend');
                found_clusters_out_resort=zeros(size(found_clusters_out));
                t=0;
                for jj=2:size(cluster_track,1)
                    t=t+1;
                    found_clusters_out_resort(found_clusters_out==clusters_size_resort(t,2))=t;
                    fprintf('cluster %d size = %d voxels\n',t,size(find(found_clusters_out_resort==t),1) );
                end
            end
            
            output_path=fullfile(pa, sprintf('%s_vthresh%s_ctrhesh%d_cluster-index_pos',na,threshval_out,clust_thresh));
            niftiwrite(single(found_clusters_out_resort),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
            
        elseif strncmp(input_param{3},'negative',5)||strncmp(input_param{3},'both',5)
            nifti_input_out(nifti_input>(-1.*threshval))=0;
            
            found_clusters=bwlabeln(nifti_input_out,conn);
            cluster_tally=unique(found_clusters);
            cluster_tally(1)=[];
            for j=1:size(cluster_tally,1)
                size_tally(j,1)=size(find(found_clusters==cluster_tally(j,1)),1);
                if size_tally(j,1)<clust_thresh
                    found_clusters(found_clusters==j)=0;
                end
            end
            found_clusters_out=bwlabeln(found_clusters,conn);
            if size(find(found_clusters_out),1)==0
                disp('Warning, no negative clusters found at this threshold');
            else
                cluster_track=unique(found_clusters_out);
                num_clusters=size(cluster_track,1)-1;
                fprintf('%d negative clusters\n',num_clusters);
                found_clusters_out_resort=found_clusters_out;
                t=0;
                for jj=2:size(cluster_track,1)
                    t=t+1;
                    clusters_size(t,1)=size(find(found_clusters_out==cluster_track(jj)),1);
                    clusters_size(t,2)=t;
                end
                
                clusters_size_resort=sortrows(clusters_size,1,'descend');
                found_clusters_out_resort=zeros(size(found_clusters_out));
                t=0;
                for jj=2:size(cluster_track,1)
                    t=t+1;
                    found_clusters_out_resort(found_clusters_out==clusters_size_resort(t,2))=t;
                    fprintf('cluster %d size = %d voxels\n',t,size(find(found_clusters_out_resort==t),1) );
                end
            end
            
            output_path=fullfile(pa, sprintf('%s_vthresh%s_ctrhesh%d_cluster-index_neg',na,threshval_out,clust_thresh));
            niftiwrite(single(found_clusters_out_resort),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
        end
    end
    
    %% make a seperate volume per cluster
    if strncmp(input_param{1},'clusters',10)
        if strncmp(input_param{3},'positive',5)||strncmp(input_param{3},'both',5)
            nifti_input_out_pos=nifti_input;
            nifti_input_out_pos(nifti_input<threshval)=0;
            found_clusters_pos=bwlabeln(nifti_input_out_pos,conn);
            
            cluster_tally=unique(found_clusters_pos);
            cluster_tally(1)=[];
            for j=1:size(cluster_tally,1)
                size_tally(j,1)=size(find(found_clusters_pos==cluster_tally(j,1)),1);
                if size_tally(j,1)<clust_thresh
                    found_clusters_pos(found_clusters_pos==j)=0;
                end
            end
            
            found_clusters_pos_struct=bwconncomp(found_clusters_pos,conn);
            if isempty(found_clusters_pos_struct.PixelIdxList)==1
                disp('Warning, no positive clusters found at this threshold');
            else
                
                clear cluster_tally_new3 found_clusters_pos_struct_resort
                found_clusters_pos_struct_resort=found_clusters_pos_struct;
                
                for jj=1:size(found_clusters_pos_struct.PixelIdxList,2)
                    cluster_tally_new3(jj,1)=size(found_clusters_pos_struct.PixelIdxList{jj},1);
                    cluster_tally_new3(jj,2)=jj;
                    % found_clusters_pos_struct_resort.PixelIdxList(jj)=
                end
                cluster_tally_new3_resort=sortrows(cluster_tally_new3,1,'descend');
                
                
                for jj=1:size(found_clusters_pos_struct.PixelIdxList,2)
                    found_clusters_pos_struct_resort.PixelIdxList(jj)=found_clusters_pos_struct.PixelIdxList(cluster_tally_new3_resort(jj,2));
                end
            end
            
            tt=0;
            for i=1:size(found_clusters_pos_struct_resort.PixelIdxList,2)
                tt=tt+1;
                nifti_input_out=zeros(size(nifti_input));
                nifti_input_out(found_clusters_pos_struct_resort.PixelIdxList{i})=tt;
                clear cluster_size
                cluster_size=size(found_clusters_pos_struct_resort.PixelIdxList{i},1);
                %% get coordinates of ROIs
                props = regionprops(true(size(nifti_input_out)), nifti_input_out, 'WeightedCentroid');
                %re-arrange coordinates
                coor(1,1)=props.WeightedCentroid(2);
                coor(1,2)=props.WeightedCentroid(1);
                coor(1,3)=props.WeightedCentroid(3);
                roi_coors=num2str(cor2mni(round(coor),nii_info_group_output.Transform.T'));
                temp_array=isspace(roi_coors);
                temp_array_temp=temp_array;
                for ii=2:size(temp_array,2)-1
                    temp_array_temp(1,ii)=(temp_array(1,ii-1)).*temp_array(1,ii).*(temp_array(1,ii+1));
                end
                temp_roi_coors=str2num(roi_coors);
                
                roi_coor_txt=sprintf('%.1f_%.1f_%.1f',temp_roi_coors(1,1),temp_roi_coors(1,2),temp_roi_coors(1,3));
                
                output_path=fullfile(pa, sprintf('%s_vthresh%s_ctrhesh%d_clust%d_size%d_pos_%s',na,threshval_out,clust_thresh,tt,cluster_size,roi_coor_txt));
                niftiwrite(single(nifti_input_out),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
            end
            
        elseif strncmp(input_param{3},'negative',5)||strncmp(input_param{3},'both',5)
            nifti_input_out_neg=nifti_input;
            nifti_input_out_neg(nifti_input<(threshval.*-1))=0;
            found_clusters_neg=bwlabeln(nifti_input_out_neg,conn);
            
            cluster_tally=unique(found_clusters_neg);
            cluster_tally(1)=[];
            for j=1:size(cluster_tally,1)
                size_tally(j,1)=size(find(found_clusters_neg==cluster_tally(j,1)),1);
                if size_tally(j,1)<clust_thresh
                    found_clusters_neg(found_clusters_neg==j)=0;
                end
            end
            
            found_clusters_neg_struct=bwconncomp(found_clusters_neg,conn);
            
            if isempty(found_clusters_neg_struct.PixelIdxList)==1
                disp('Warning, no negative clusters found at this threshold');
            else
                
                clear cluster_tally_new3 found_clusters_pos_struct_resort
                found_clusters_pos_struct_resort=found_clusters_pos_struct;
                
                for jj=1:size(found_clusters_pos_struct.PixelIdxList,2)
                    cluster_tally_new3(jj,1)=size(found_clusters_pos_struct.PixelIdxList{jj},1);
                    cluster_tally_new3(jj,2)=jj;
                    % found_clusters_pos_struct_resort.PixelIdxList(jj)=
                end
                cluster_tally_new3_resort=sortrows(cluster_tally_new3,1,'descend');
                
                
                for jj=1:size(found_clusters_pos_struct.PixelIdxList,2)
                    found_clusters_pos_struct_resort.PixelIdxList(jj)=found_clusters_pos_struct.PixelIdxList(cluster_tally_new3_resort(jj,2));
                end
            end
            
            tt=0;
            for i=1:size(found_clusters_pos_struct_resort.PixelIdxList,2)
                
                tt=tt+1;
                nifti_input_out=zeros(size(nifti_input));
                nifti_input_out(found_clusters_pos_struct_resort.PixelIdxList{i})=tt;
                clear cluster_size
                cluster_size=size(found_clusters_pos_struct_resort.PixelIdxList{i},1);
                %% get coordinates of ROIs
                props = regionprops(true(size(nifti_input_out)), nifti_input_out, 'WeightedCentroid');
                %re-arrange coordinates
                coor(1,1)=props.WeightedCentroid(2);
                coor(1,2)=props.WeightedCentroid(1);
                coor(1,3)=props.WeightedCentroid(3);
                roi_coors=num2str(cor2mni(round(coor),nii_info_group_output.Transform.T'));
                temp_array=isspace(roi_coors);
                temp_array_temp=temp_array;
                for ii=2:size(temp_array,2)-1
                    temp_array_temp(1,ii)=(temp_array(1,ii-1)).*temp_array(1,ii).*(temp_array(1,ii+1));
                end
                temp_roi_coors=str2num(roi_coors);
                
                roi_coor_txt=sprintf('%.1f_%.1f_%.1f',temp_roi_coors(1,1),temp_roi_coors(1,2),temp_roi_coors(1,3));
                output_path=fullfile(pa, sprintf('%s_vthresh%s_ctrhesh%d_clust%d_size%d_neg_%s',na,threshval_out,clust_thresh,tt,cluster_size,roi_coor_txt));
                niftiwrite(single(nifti_input_out),output_path,nii_info_group_output,'Compressed',false, 'Combined', true);
            end
        end
    end
end
